HOW TO RUN PROGRAM:
1) Compile with GCC
$gcc --std=gnu99 -o movies main.c
2) run program with CSV as an argument
ex: $./movies movies.csv
